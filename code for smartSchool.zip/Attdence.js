// src/AttendanceForm.js
import React, { useState } from 'react';
import axios from 'axios';

const AttendanceForm = () => {
    const [uid, setUid] = useState('');
    const [attendance, setAttendance] = useState('');
    const [schoolCode, setSchoolCode] = useState('');
    const [message, setMessage] = useState('');

    // Handle form submission
    const handleSubmit = async (event) => {
        event.preventDefault();

        // Prepare data to send to the API
        const data = {
            uid: uid,
            attendance: attendance,
            school_code: schoolCode
        };

        try {
            // Make POST request to your PHP API
            const response = await axios.post('https://codtsmartschool.strangeweb.info/attendance.php', data, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.data.success) {
                setMessage('Attendance recorded successfully!');
            } else {
                setMessage('Error: ' + response.data.message);
            }
        } catch (error) {
            setMessage('Error: Unable to record attendance.');
        }
    };

    return (
        <div>
            <h2>Record Attendance</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>UID:</label>
                    <input 
                        type="number" 
                        value={uid} 
                        onChange={(e) => setUid(e.target.value)} 
                        required 
                    />
                </div>
                <div>
                    <label>Attendance Status:</label>
                    <input 
                        type="text" 
                        value={attendance} 
                        onChange={(e) => setAttendance(e.target.value)} 
                        required 
                    />
                </div>
                <div>
                    <label>School Code:</label>
                    <input 
                        type="text" 
                        value={schoolCode} 
                        onChange={(e) => setSchoolCode(e.target.value)} 
                        required 
                    />
                </div>
                <button type="submit">Submit</button>
            </form>

            {message && <p>{message}</p>}
        </div>
    );
};

export default AttendanceForm;
