import React, { useState, useEffect } from 'react';

const SyllabusComponent = () => {
    const [syllabusList, setSyllabusList] = useState([]);
    const [subject, setSubject] = useState('');
    const [syllabus, setSyllabus] = useState('');
    const [schoolcode, setSchoolcode] = useState('');
    const [editId, setEditId] = useState(null);
    const API_URL = "https://codtsmartschool.strangeweb.info/sallaybers.php"; // Your API URL

    // Fetch all syllabus when the component mounts
    useEffect(() => {
        const fetchData = async () => {
            const data = await getAllSyllabus();
            setSyllabusList(data);
        };
        fetchData();
    }, []);

    // Function to get all syllabus
    const getAllSyllabus = async () => {
        try {
            const response = await fetch(API_URL);
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error fetching syllabus:', error);
            return [];
        }
    };

    // Function to create syllabus
    const handleCreateSyllabus = async () => {
        if (!subject || !syllabus || !schoolcode) return;

        const result = await createSyllabus(subject, syllabus, schoolcode);
        alert(result.message);

        // Re-fetch data after creating
        const data = await getAllSyllabus();
        setSyllabusList(data);

        // Clear the form fields
        setSubject('');
        setSyllabus('');
        setSchoolcode('');
    };

    // Function to create syllabus on the backend
    const createSyllabus = async (subject, syllabus, schoolcode) => {
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ subject, syllabus, schoolcode }),
            });
            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Error creating syllabus:', error);
            return { message: 'Failed to create syllabus.' };
        }
    };

    // Function to update syllabus
    const handleUpdateSyllabus = async () => {
        if (!editId || !subject || !syllabus || !schoolcode) return;

        const result = await updateSyllabus(editId, subject, syllabus, schoolcode);
        alert(result.message);

        // Re-fetch data after updating
        const data = await getAllSyllabus();
        setSyllabusList(data);

        // Clear the form fields
        setSubject('');
        setSyllabus('');
        setSchoolcode('');
        setEditId(null);
    };

    // Function to update syllabus on the backend
    const updateSyllabus = async (id, subject, syllabus, schoolcode) => {
        try {
            const response = await fetch(API_URL, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id, subject, syllabus, schoolcode }),
            });
            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Error updating syllabus:', error);
            return { message: 'Failed to update syllabus.' };
        }
    };

    // Function to delete syllabus
    const handleDeleteSyllabus = async (id) => {
        const result = await deleteSyllabus(id);
        alert(result.message);

        // Re-fetch data after deletion
        const data = await getAllSyllabus();
        setSyllabusList(data);
    };

    // Function to delete syllabus on the backend
    const deleteSyllabus = async (id) => {
        try {
            const response = await fetch(API_URL, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id }),
            });
            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Error deleting syllabus:', error);
            return { message: 'Failed to delete syllabus.' };
        }
    };

    // Function to fetch syllabus by ID for editing
    const handleEditSyllabus = async (id) => {
        const data = await getSyllabusById(id);
        if (data) {
            setSubject(data.subject);
            setSyllabus(data.syllabus);
            setSchoolcode(data.schoolcode);
            setEditId(id);
        }
    };

    // Function to get syllabus by ID
    const getSyllabusById = async (id) => {
        try {
            const response = await fetch(`${API_URL}?id=${id}`);
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error fetching syllabus by ID:', error);
            return null;
        }
    };

    return (
        <div>
            <h2>Syllabus Management</h2>
            
            <div>
                <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Subject"
                />
                <input
                    type="text"
                    value={syllabus}
                    onChange={(e) => setSyllabus(e.target.value)}
                    placeholder="Syllabus"
                />
                <input
                    type="number"
                    value={schoolcode}
                    onChange={(e) => setSchoolcode(e.target.value)}
                    placeholder="School Code"
                />
                {editId ? (
                    <button onClick={handleUpdateSyllabus}>Update Syllabus</button>
                ) : (
                    <button onClick={handleCreateSyllabus}>Create Syllabus</button>
                )}
            </div>

            <h3>Syllabus List</h3>
            <ul>
                {syllabusList.map((item) => (
                    <li key={item.id}>
                        <strong>{item.subject}</strong>: {item.syllabus} (School Code: {item.schoolcode})
                        <button onClick={() => handleEditSyllabus(item.id)}>Edit</button>
                        <button onClick={() => handleDeleteSyllabus(item.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default SyllabusComponent;
