import React, { useState } from "react";

const SubmitAssignment = () => {
  const [formData, setFormData] = useState({
    aid: "",
    sid: "",
    subject: "",
    marks: "",
    answers: "",
    datetime: "",
  });

  const [responseMessage, setResponseMessage] = useState("");

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(
        "https://codtsmartschool.strangeweb.info/studentapi/submit-assinment.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();

      if (response.ok) {
        setResponseMessage("Assignment submitted successfully!");
      } else {
        setResponseMessage(data.message || "Failed to submit assignment.");
      }
    } catch (error) {
      console.error("Error:", error);
      setResponseMessage("An error occurred. Please try again later.");
    }
  };

  return (
    <div>
      <h2>Submit Assignment</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Assignment ID:</label>
          <input
            type="number"
            name="aid"
            value={formData.aid}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Student ID:</label>
          <input
            type="number"
            name="sid"
            value={formData.sid}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Subject:</label>
          <input
            type="text"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Marks:</label>
          <input
            type="number"
            name="marks"
            value={formData.marks}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Answers:</label>
          <input
            type="text"
            name="answers"
            value={formData.answers}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Date and Time:</label>
          <input
            type="datetime-local"
            name="datetime"
            value={formData.datetime}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Submit Assignment</button>
      </form>

      {responseMessage && <p>{responseMessage}</p>}
    </div>
  );
};

export default SubmitAssignment;
